# Databricks notebook source
# MAGIC %md
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import sys
project_pth=os.path.join(os.getcwd(),'..','..')
sys.path.append(project_pth)

from utils.Transformations import reusable

# COMMAND ----------

# MAGIC %md
# MAGIC **DimUser**
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## AUTOLOADER

# COMMAND ----------

df_user = spark.readStream.format("cloudFiles")\
                .option("cloudFiles.format","parquet")\
                .option("cloudFiles.schemaLocation","abfss://silver@storageazureshan.dfs.core.windows.net/DimUser/checkpoint")\
                .option("cloudFiles.schemaEvolutionMode","addNewColumns")\
                .load("abfss://bronze@storageazureshan.dfs.core.windows.net/DimUser")

# COMMAND ----------

   query = (df_user.writeStream
       .format("delta")
       .outputMode("append")
       .trigger(availableNow=True)
       .option("checkpointLocation", "abfss://silver@storageazureshan.dfs.core.windows.net/DimUser/checkpoint_write")
       .start("abfss://silver@storageazureshan.dfs.core.windows.net/DimUser/data"))
   query.awaitTermination()

# COMMAND ----------

display(df_user, checkpointLocation="abfss://silver@storageazureshan.dfs.core.windows.net/DimUser/checkpoint_display_v4")

# COMMAND ----------

df_user=df_user.withColumn("user_name",upper(col("user_name")))


# COMMAND ----------

df_user_obj = reusable()
df_user=df_user_obj.dropColumns(df_user,['_rescued_data'])
df_user=df_user_obj.dropDuplicates(df_user,['user_id'])


# COMMAND ----------

df_user.writeStream.format("delta")\
        .outputMode("append")\
        .option("checkpointLocation","abfss://silver@storageazureshan.dfs.core.windows.net/DimUser/chekpoint")\
        .trigger(once=True)\
        .option("path","abfss://silver@storageazureshan.dfs.core.windows.net/DimUser/data")\
        .toTable("spotify_cata.silver.DimUser")

# COMMAND ----------

# MAGIC %md
# MAGIC *DimArtist*

# COMMAND ----------

df_art = spark.readStream.format("cloudFiles")\
            .option("cloudFiles.format","parquet")\
            .option("cloudFiles.schemaLocation","abfss://silver@storageazureshan.dfs.core.windows.net/DimArtist/checkpoint")\
            .option("cloudFiles.schemaEvolutionMode","addNewColumns")\
            .load("abfss://bronze@storageazureshan.dfs.core.windows.net/DimArtist")

# COMMAND ----------

df_art.writeStream.format("delta")\
        .outputMode("append")\
        .option("checkpointLocation","abfss://silver@storageazureshan.dfs.core.windows.net/DimArtist/checkpoint_write2")\
        .trigger(availableNow=True)\
        .start("abfss://silver@storageazureshan.dfs.core.windows.net/DimArtist/data2")

# COMMAND ----------

display(spark.read.format("delta").load("abfss://silver@storageazureshan.dfs.core.windows.net/DimArtist/data2"))

# COMMAND ----------

df_art_obj = reusable()

df_art =df_art_obj.dropColumns(df_art,['_rescued_data'])
df_art =df_art_obj.dropDuplicates(df_art,['artist_id'])

# COMMAND ----------

df_art.writeStream.format("delta")\
        .outputMode("append")\
        .option("checkpointLocation","abfss://silver@storageazureshan.dfs.core.windows.net/DimArt/chekpoint")\
        .trigger(once=True)\
        .option("path","abfss://silver@storageazureshan.dfs.core.windows.net/DimArt/data")\
        .toTable("spotify_cata.silver.DimArtist")

# COMMAND ----------

display(spark.read.format("delta").load("abfss://silver@storageazureshan.dfs.core.windows.net/DimArt/data"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## DimTrack

# COMMAND ----------

   df_track = spark.readStream.format("cloudFiles")\
       .option("cloudFiles.format","parquet")\
       .option("cloudFiles.schemaLocation","abfss://silver@storageazureshan.dfs.core.windows.net/DimTrack/checkpoint")\
       .option("cloudFiles.schemaEvolutionMode","addNewColumns")\
       .load("abfss://bronze@storageazureshan.dfs.core.windows.net/DimTrack")

# COMMAND ----------

df_track = df_track.withColumn("durationFlag",
    when(col('duration_sec') < 150, "low")
    .when(col('duration_sec') < 300, "medium")
    .otherwise("high"))

df_track = df_track.withColumn("track_name", regexp_replace(col('track_name'), '-', ' '))

df_track_obj = reusable()
df_track = df_track_obj.dropColumns(df_track, ['_rescued_data'])
df_track = df_track_obj.dropDuplicates(df_track, ['track_id'])

# COMMAND ----------

query = (df_track.writeStream.format("delta")
    .outputMode("append")
    .option("checkpointLocation","abfss://silver@storageazureshan.dfs.core.windows.net/DimTrack/checkpoint_write")
    .trigger(availableNow=True)
    .start("abfss://silver@storageazureshan.dfs.core.windows.net/DimTrack/data"))
query.awaitTermination()

# COMMAND ----------

   display(spark.read.format("delta").load("abfss://silver@storageazureshan.dfs.core.windows.net/DimTrack/data"))

# COMMAND ----------

df_raw = spark.read.format("parquet").load("abfss://bronze@storageazureshan.dfs.core.windows.net/DimTrack")
display(df_raw)

# COMMAND ----------

# MAGIC %md
# MAGIC ## DimDate
# MAGIC

# COMMAND ----------

df_date = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format","parquet")\
    .option("cloudFiles.schemaLocation","abfss://silver@storageazureshan.dfs.core.windows.net/DimDate/checkpoint")\
    .option("cloudFiles.schemaEvolutionMode","addNewColumns")\
    .load("abfss://bronze@storageazureshan.dfs.core.windows.net/DimDate")

# COMMAND ----------

df_date_obj = reusable()
df_date = df_date_obj.dropColumns(df_date, ['_rescued_data'])
df_date = df_date_obj.dropDuplicates(df_date, ['date_key'])

# COMMAND ----------

query = (df_date.writeStream.format("delta")
    .outputMode("append")
    .option("checkpointLocation","abfss://silver@storageazureshan.dfs.core.windows.net/DimDate/checkpoint_write")
    .trigger(availableNow=True)
    .start("abfss://silver@storageazureshan.dfs.core.windows.net/DimDate/data"))
query.awaitTermination()

# COMMAND ----------

# MAGIC %md
# MAGIC **FactStream**

# COMMAND ----------

df_fact = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format","parquet")\
    .option("cloudFiles.schemaLocation","abfss://silver@storageazureshan.dfs.core.windows.net/FactStream/checkpoint")\
    .option("cloudFiles.schemaEvolutionMode","addNewColumns")\
    .load("abfss://bronze@storageazureshan.dfs.core.windows.net/FactStream")

# COMMAND ----------

df_fact_obj = reusable()
df_fact = df_fact_obj.dropColumns(df_fact, ['_rescued_data'])

# COMMAND ----------

query = (df_fact.writeStream.format("delta")
    .outputMode("append")
    .option("checkpointLocation","abfss://silver@storageazureshan.dfs.core.windows.net/FactStream/checkpoint_write")
    .trigger(availableNow=True)
    .start("abfss://silver@storageazureshan.dfs.core.windows.net/FactStream/data"))
query.awaitTermination()

# COMMAND ----------

spark.sql("""CREATE TABLE IF NOT EXISTS spotify_cata.silver.dimtrack
USING DELTA
LOCATION 'abfss://silver@storageazureshan.dfs.core.windows.net/DimTrack/data'""")

spark.sql("""CREATE TABLE IF NOT EXISTS spotify_cata.silver.dimdate
USING DELTA
LOCATION 'abfss://silver@storageazureshan.dfs.core.windows.net/DimDate/data'""")

spark.sql("""CREATE TABLE IF NOT EXISTS spotify_cata.silver.factstream
USING DELTA
LOCATION 'abfss://silver@storageazureshan.dfs.core.windows.net/FactStream/data'""")

# COMMAND ----------

