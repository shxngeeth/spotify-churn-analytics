# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC    %sql
# MAGIC    SELECT * FROM spotify_cata.silver.dimuser

# COMMAND ----------

