# Databricks notebook source
spark.sql("DROP SCHEMA IF EXISTS spotify_cata.gold CASCADE")
spark.sql("CREATE SCHEMA spotify_cata.gold")

# COMMAND ----------

for t in ["dimartist", "dimtrack", "dimdate"]:
    (spark.table(f"spotify_cata.silver.{t}")
        .write.format("delta").mode("overwrite")
        .option("path", f"abfss://gold@storageazureshan.dfs.core.windows.net/{t}")
        .saveAsTable(f"spotify_cata.gold.{t}"))

# COMMAND ----------

from jinja2 import Template

parameters = [
    {
        "table": "spotify_cata.silver.factstream",
        "alias": "factstream",
        "cols": "factstream.stream_id, factstream.listen_duration"
    },
    {
        "table": "spotify_cata.silver.dimuser",
        "alias": "dimuser",
        "cols": "dimuser.user_id, dimuser.user_name",
        "condition": "factstream.user_id = dimuser.user_id"
    },
    {
        "table": "spotify_cata.silver.dimtrack",
        "alias": "dimtrack",
        "cols": "dimtrack.track_id, dimtrack.track_name",
        "condition": "factstream.track_id = dimtrack.track_id"
    },
    {
        "table": "spotify_cata.silver.dimdate",
        "alias": "dimdate",
        "cols": "dimdate.date_key, dimdate.date",
        "condition": "factstream.date_key = dimdate.date_key"
    }
]

query_text = """
SELECT
  {% for p in parameters %}
    {{ p.cols }}{% if not loop.last %},{% endif %}
  {% endfor %}
FROM {{ parameters[0].table }} AS {{ parameters[0].alias }}
{% for p in parameters[1:] %}
LEFT JOIN {{ p.table }} AS {{ p.alias }}
  ON {{ p.condition }}
{% endfor %}
"""

query = Template(query_text).render(parameters=parameters)
print(query)

# COMMAND ----------

df_gold = spark.sql(query)
(df_gold.write.format("delta").mode("overwrite")
    .option("path", "abfss://gold@storageazureshan.dfs.core.windows.net/factstream_enriched")
    .saveAsTable("spotify_cata.gold.factstream_enriched"))

# COMMAND ----------

spark.sql("SHOW TABLES IN spotify_cata.gold").show()

# COMMAND ----------

   spark.sql("""
   CREATE TABLE IF NOT EXISTS spotify_cata.gold.dimuser (
     user_id INT, user_name STRING, country STRING, subscription_type STRING,
     start_date DATE, end_date DATE, updated_at TIMESTAMP,
     __START_AT TIMESTAMP, __END_AT TIMESTAMP
   )
   USING DELTA
   LOCATION 'abfss://gold@storageazureshan.dfs.core.windows.net/DimUser'
   """)

# COMMAND ----------

   from pyspark.sql.functions import lit, col

   src = spark.table("spotify_cata.silver.dimuser") \
       .withColumn("__START_AT", col("updated_at")) \
       .withColumn("__END_AT", lit(None).cast("timestamp"))
   src.createOrReplaceTempView("src")

# COMMAND ----------

   spark.sql("""
   MERGE INTO spotify_cata.gold.dimuser t
   USING src s
   ON t.user_id = s.user_id AND t.__END_AT IS NULL
   WHEN MATCHED AND (t.user_name <> s.user_name OR t.country <> s.country
                     OR t.subscription_type <> s.subscription_type)
     THEN UPDATE SET t.__END_AT = s.updated_at
   """)

# COMMAND ----------

   spark.sql("""
   INSERT INTO spotify_cata.gold.dimuser
   SELECT s.* FROM src s
   LEFT JOIN spotify_cata.gold.dimuser t
     ON t.user_id = s.user_id AND t.__END_AT IS NULL
   WHERE t.user_id IS NULL
   """)

# COMMAND ----------

   spark.sql("SHOW TABLES IN spotify_cata.gold").show()
   display(spark.table("spotify_cata.gold.dimuser"))

# COMMAND ----------

display(spark.sql("SELECT user_id, user_name, __START_AT, __END_AT FROM spotify_cata.gold.dimuser LIMIT 10"))

# COMMAND ----------

display(spark.sql("""
SELECT user_id, user_name, country, __START_AT, __END_AT
FROM spotify_cata.gold.dimuser WHERE user_id = 148
"""))

# COMMAND ----------

spark.sql("""
UPDATE spotify_cata.silver.dimuser
SET country = 'Testland', updated_at = current_timestamp()
WHERE user_id = 148
""")

# COMMAND ----------

from pyspark.sql.functions import lit, col
src = spark.table("spotify_cata.silver.dimuser") \
    .withColumn("__START_AT", col("updated_at")) \
    .withColumn("__END_AT", lit(None).cast("timestamp"))
src.createOrReplaceTempView("src")

# COMMAND ----------

spark.sql("""
MERGE INTO spotify_cata.gold.dimuser t
USING src s
ON t.user_id = s.user_id AND t.__END_AT IS NULL
WHEN MATCHED AND (t.user_name <> s.user_name OR t.country <> s.country
                  OR t.subscription_type <> s.subscription_type)
  THEN UPDATE SET t.__END_AT = s.updated_at
""")

# COMMAND ----------

spark.sql("""
INSERT INTO spotify_cata.gold.dimuser
SELECT s.* FROM src s
LEFT JOIN spotify_cata.gold.dimuser t
  ON t.user_id = s.user_id AND t.__END_AT IS NULL
WHERE t.user_id IS NULL
""")

# COMMAND ----------

display(spark.sql("""
SELECT user_id, user_name, country, __START_AT, __END_AT
FROM spotify_cata.gold.dimuser WHERE user_id = 148
ORDER BY __START_AT
"""))