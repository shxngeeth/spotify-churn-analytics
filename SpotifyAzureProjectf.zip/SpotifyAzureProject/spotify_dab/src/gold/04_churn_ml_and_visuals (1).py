# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %md
# MAGIC # 04 - Churn analytics, machine learning and executive visuals
# MAGIC
# MAGIC **Business case:** Spotify used as a hypothetical case study (a subscription-based digital retailer). All data is synthetic, not Spotify's real data.
# MAGIC **Data:** synthetic sample built through the bronze / silver / gold pipeline (see `gold_layer`).
# MAGIC **Reads:** `spotify_cata.gold.dimuser` (current SCD2 rows), `spotify_cata.gold.factstream_enriched`.
# MAGIC
# MAGIC Sections: 0 checks, 1 feature table, 2 churn model, 3 evaluation, 4 executive charts, 5 optional clustering.

# COMMAND ----------

for t in ["dimuser", "dimtrack", "dimdate", "dimartist", "factstream_enriched"]:
    print(t, spark.table(f"spotify_cata.gold.{t}").count())

spark.table("spotify_cata.gold.dimuser").printSchema()
spark.table("spotify_cata.gold.factstream_enriched").printSchema()

# COMMAND ----------

# One current row per user is required (SCD2 keeps history rows with __END_AT filled in).
cur = spark.table("spotify_cata.gold.dimuser").where("__END_AT IS NULL")
print("current rows:", cur.count(), "| distinct users:", cur.select("user_id").distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Feature table (one row per user)
# MAGIC Label: `churned = 1` when the user has NO streams after a cutoff date (inactive = lost). The `end_date` column is empty in this synthetic data, so inactivity is used as the churn definition.
# MAGIC Features use only activity BEFORE the cutoff; the label uses activity AFTER it, so the model predicts the future instead of repeating the label.

# COMMAND ----------

features = spark.sql("""
WITH bounds AS (
  SELECT MIN(`date`) AS d0, MAX(`date`) AS d1
  FROM spotify_cata.gold.factstream_enriched
),
cut AS (
  -- cutoff = 70% of the way through the stream history; later activity is only used for the label
  SELECT DATE_ADD(d0, CAST(0.7 * DATEDIFF(d1, d0) AS INT)) AS cutoff FROM bounds
),
usage AS (
  SELECT f.user_id,
         COUNT(*)                 AS total_streams,
         SUM(f.listen_duration)   AS total_listen,
         AVG(f.listen_duration)   AS avg_listen,
         COUNT(DISTINCT f.track_id) AS distinct_tracks,
         MAX(f.`date`)            AS last_stream_date
  FROM spotify_cata.gold.factstream_enriched f CROSS JOIN cut c
  WHERE f.`date` <= c.cutoff
  GROUP BY f.user_id
),
future AS (
  SELECT DISTINCT f.user_id
  FROM spotify_cata.gold.factstream_enriched f CROSS JOIN cut c
  WHERE f.`date` > c.cutoff
)
SELECT u.user_id,
       u.country,
       u.subscription_type,
       DATEDIFF(c.cutoff, u.start_date)             AS tenure_days,
       a.total_streams,
       a.total_listen,
       a.avg_listen,
       a.distinct_tracks,
       DATEDIFF(c.cutoff, a.last_stream_date)       AS days_since_last_stream,
       CASE WHEN fu.user_id IS NULL THEN 1 ELSE 0 END AS churned
FROM spotify_cata.gold.dimuser u
CROSS JOIN cut c
JOIN usage a ON a.user_id = u.user_id
LEFT JOIN future fu ON fu.user_id = u.user_id
WHERE u.__END_AT IS NULL
""")

# Save as an external gold table (explicit path avoids the managed-storage problem in this workspace).
(features.write.format("delta").mode("overwrite")
    .option("path", "abfss://gold@storageazureshan.dfs.core.windows.net/churn_features")
    .saveAsTable("spotify_cata.gold.churn_features"))

display(features.groupBy("churned").count())

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Churn model (logistic regression)
# MAGIC
# MAGIC `class_weight="balanced"` stops the model ignoring the minority class.
# MAGIC Country is left out of the model (hundreds of levels for a few hundred users would overfit) but is used in the charts.

# COMMAND ----------

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (classification_report, confusion_matrix,
                             roc_auc_score, RocCurveDisplay)

pdf = features.toPandas()

num_cols = ["tenure_days", "total_streams", "total_listen", "avg_listen",
            "distinct_tracks", "days_since_last_stream"]
cat_cols = ["subscription_type"]

pdf[num_cols] = pdf[num_cols].astype(float).fillna(0)

X = pdf[num_cols + cat_cols]
y = pdf["churned"].astype(int)

counts = y.value_counts()
print("Class counts:\n", counts)
if counts.min() < 10:
    raise ValueError("Too few examples of one class for a reliable churn model - use section 5 instead.")

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y)

prep = ColumnTransformer([
    ("num", StandardScaler(), num_cols),
    ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
])

model = Pipeline([
    ("prep", prep),
    ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
])
model.fit(X_train, y_train)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Evaluation
# MAGIC Accuracy alone is misleading when classes are unbalanced, so report AUC, precision, recall and a baseline.
# MAGIC With synthetic data an AUC close to 0.5 is a legitimate finding: it means the features carry little signal.

# COMMAND ----------

proba = model.predict_proba(X_test)[:, 1]
pred = (proba >= 0.5).astype(int)

baseline = max(y_test.mean(), 1 - y_test.mean())
print("Majority-class baseline accuracy:", round(baseline, 3))
print("Test ROC AUC:", round(roc_auc_score(y_test, proba), 3))
print()
print(classification_report(y_test, pred, digits=3))
print("Confusion matrix (rows = actual, cols = predicted):")
print(confusion_matrix(y_test, pred))

# Small data gives unstable splits, so also check 5-fold cross-validation.
cv = cross_val_score(model, X, y, cv=5, scoring="roc_auc")
print("5-fold CV ROC AUC: mean", round(cv.mean(), 3), "| std", round(cv.std(), 3))

# COMMAND ----------

fig, ax = plt.subplots(figsize=(5, 5))
RocCurveDisplay.from_predictions(y_test, proba, ax=ax)
ax.plot([0, 1], [0, 1], linestyle="--", color="grey", label="Random guess")
ax.set_title("Churn model: ROC curve")
ax.legend()
plt.show()

# COMMAND ----------

names = model.named_steps["prep"].get_feature_names_out()
names = [n.split("__", 1)[1] for n in names]
coefs = model.named_steps["clf"].coef_[0]
coef_df = pd.DataFrame({"feature": names, "coefficient": coefs}).sort_values("coefficient")

fig, ax = plt.subplots(figsize=(7, 4.5))
ax.barh(coef_df["feature"], coef_df["coefficient"])
ax.axvline(0, color="black", linewidth=0.8)
ax.set_title("What pushes churn risk up (right) or down (left)")
ax.set_xlabel("Logistic regression coefficient (features standardised)")
plt.tight_layout()
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Executive charts
# MAGIC

# COMMAND ----------

# Chart 1: churn rate by plan
plan = pdf.groupby("subscription_type")["churned"].agg(["mean", "count"]).reset_index()
plan["churn_pct"] = plan["mean"] * 100

fig, ax = plt.subplots(figsize=(7, 4))
ax.bar(plan["subscription_type"], plan["churn_pct"])
ax.set_title("Churn rate by subscription plan")
ax.set_ylabel("Users who cancelled (%)")
for i, v in enumerate(plan["churn_pct"]):
    ax.text(i, v, f"{v:.1f}%", ha="center", va="bottom")
plt.tight_layout()
plt.show()

# COMMAND ----------

# Chart 2: top 10 markets by total listening time
# Units of listen_duration are as stored in the source (confirm seconds/minutes before labelling on a slide).
top = (pdf.groupby("country")["total_listen"].sum()
         .sort_values(ascending=False).head(10).sort_values())

fig, ax = plt.subplots(figsize=(7, 4.5))
ax.barh(top.index, top.values)
ax.set_title("Top 10 markets by total listening time")
ax.set_xlabel("Total listening time (source units)")
plt.tight_layout()
plt.show()

# COMMAND ----------

# Chart 3: engagement of retained vs churned users
eng = pdf.groupby("churned")[["total_streams", "days_since_last_stream"]].mean()
eng.index = ["Retained" if i == 0 else "Churned" for i in eng.index]

fig, axes = plt.subplots(1, 2, figsize=(9, 4))
axes[0].bar(eng.index, eng["total_streams"])
axes[0].set_title("Average streams per user")
axes[1].bar(eng.index, eng["days_since_last_stream"])
axes[1].set_title("Average days since last stream")
plt.tight_layout()
plt.show()

# COMMAND ----------

# Chart 4: monthly streaming trend
trend = spark.sql("""
SELECT DATE_TRUNC('month', `date`) AS month, COUNT(*) AS streams
FROM spotify_cata.gold.factstream_enriched
GROUP BY 1
ORDER BY 1
""").toPandas()

fig, ax = plt.subplots(figsize=(8, 4))
ax.plot(trend["month"], trend["streams"], marker="o")
ax.set_title("Streams per month")
ax.set_ylabel("Number of streams")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# COMMAND ----------

# Optional: save any figure as an image for the slides.
# After running a chart cell, use the image's download option in the notebook output (right-click > Save image).

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Optional fallback: customer segments (k-means)
# MAGIC Use this if the churn labels are too unbalanced for section 2, or as a second technique.
# MAGIC Unsupervised, so there is no accuracy score; judge it by whether the segments are distinct and useful.

# COMMAND ----------

from sklearn.cluster import KMeans

seg_cols = ["tenure_days", "total_streams", "avg_listen", "distinct_tracks", "days_since_last_stream"]
seg = pdf[seg_cols].astype(float).fillna(0)
scaled = StandardScaler().fit_transform(seg)

km = KMeans(n_clusters=4, random_state=42, n_init=10).fit(scaled)
pdf["segment"] = km.labels_

summary = pdf.groupby("segment").agg(
    users=("user_id", "count"),
    avg_streams=("total_streams", "mean"),
    avg_days_inactive=("days_since_last_stream", "mean"),
    churn_rate=("churned", "mean"),
).round(2)
display(spark.createDataFrame(summary.reset_index()))

# COMMAND ----------

# List the gold tables
display(spark.sql("SHOW TABLES IN spotify_cata.gold"))

# Columns of every gold table
for t in ["dimuser", "dimtrack", "dimartist", "dimdate", "factstream_enriched"]:
    print("====", t)
    display(spark.sql(f"DESCRIBE TABLE spotify_cata.gold.{t}"))

# COMMAND ----------

# Users who have more than one row = history was kept
display(spark.sql("""
SELECT user_id, COUNT(*) AS versions
FROM spotify_cata.gold.dimuser
GROUP BY user_id HAVING COUNT(*) > 1
"""))

# The before/after for user 148 (screenshot this one)
display(spark.sql("""
SELECT user_id, country, subscription_type, __START_AT, __END_AT
FROM spotify_cata.gold.dimuser
WHERE user_id = 148
ORDER BY __START_AT
"""))

# COMMAND ----------

pdf = spark.table("spotify_cata.gold.churn_features").toPandas()
y = pdf["churned"].astype(int)
print(y.value_counts())
print("Total users:", len(pdf))

# COMMAND ----------

# Show the files in each layer 
for c in ["bronze", "silver", "gold"]:
    print("====", c)
    display(dbutils.fs.ls(f"abfss://{c}@storageazureshan.dfs.core.windows.net/"))

# Show the watermark file contents 
print(dbutils.fs.head("abfss://bronze@storageazureshan.dfs.core.windows.net/DimUser_cdc/cdc.json"))

# COMMAND ----------

for t in ["dimuser", "dimtrack", "dimartist", "dimdate", "factstream_enriched"]:
    print("====", t, "rows:", spark.table(f"spotify_cata.gold.{t}").count())
    display(spark.table(f"spotify_cata.gold.{t}").limit(10))