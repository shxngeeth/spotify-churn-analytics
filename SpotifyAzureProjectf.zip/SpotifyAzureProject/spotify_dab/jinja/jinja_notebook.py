# Databricks notebook source
parameters = [
    {
        "table": "spotify_cata.silver.factstream",
        "alias": "factstream",
        "cols": "factstream.stream_id, factstream.listen_duration"
    },
    {
        "table": "spotify_cata.silver.dimuser",
        "alias": "dimuser",
        "cols": "dimuser.user_id, dimuser.user_name",
        "condition": "factstream.user_id = dimuser.user_id"
    },
    {
        "table": "spotify_cata.silver.dimtrack",
        "alias": "dimtrack",
        "cols": "dimtrack.track_id, dimtrack.track_name",
        "condition": "factstream.track_id = dimtrack.track_id"
    },
    {
        "table": "spotify_cata.silver.dimdate",
        "alias": "dimdate",
        "cols": "dimdate.date_key, dimdate.date",
        "condition": "factstream.date_key = dimdate.date_key"
    }
]

# COMMAND ----------

from jinja2 import Template

query_text = """
SELECT
  {% for p in parameters %}
    {{ p.cols }}{% if not loop.last %},{% endif %}
  {% endfor %}
FROM {{ parameters[0].table }} AS {{ parameters[0].alias }}
{% for p in parameters[1:] %}
LEFT JOIN {{ p.table }} AS {{ p.alias }}
  ON {{ p.condition }}
{% endfor %}
"""

query = Template(query_text).render(parameters=parameters)
print(query)

# COMMAND ----------

display(spark.sql(query))

# COMMAND ----------

# MAGIC %md
# MAGIC